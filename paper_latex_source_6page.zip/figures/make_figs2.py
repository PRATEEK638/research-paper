import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec

plt.rcParams.update({"pdf.fonttype": 42, "ps.fonttype": 42,
                     "font.family": "DejaVu Sans", "axes.linewidth": 0.5})

BL, OR = "#1f5c8b", "#d2691e"
BLE, ORE = "#123c5c", "#96491a"


def style(ax, ylab, ymax, yticks):
    ax.set_ylabel(ylab, fontsize=4.6, labelpad=1.5)
    ax.set_ylim(0, ymax)
    ax.set_yticks(yticks)
    ax.tick_params(axis="y", labelsize=4.2, length=1.6, width=0.4, pad=1.0)
    ax.tick_params(axis="x", length=0, pad=1.2)
    ax.grid(axis="y", color="#cfcfcf", linewidth=0.35, alpha=0.9)
    ax.set_axisbelow(True)
    for sp in ("top", "right"):
        ax.spines[sp].set_visible(False)
    for sp in ("left", "bottom"):
        ax.spines[sp].set_linewidth(0.45)


fig = plt.figure(figsize=(3.45, 2.24), dpi=600)
gs = GridSpec(2, 3, figure=fig, height_ratios=[1.20, 1.0],
              hspace=0.62, wspace=0.55,
              left=0.105, right=0.995, top=0.90, bottom=0.115)

# ---- (a) latency ---------------------------------------------------------
ax = fig.add_subplot(gs[0, :])
modes = ["Simple\nfile op", "Local LLM\n(GPU warm)", "Local LLM\n(cold start)",
         "Cloud API\n(Gemini)", "Multi-step\nplan (ARIA)", "Multi-step\nplan (Mark)"]
vals = [0.6, 1.4, 4.2, 0.9, 5.8, 2.6]
cols = [BL, BL, BL, OR, BL, OR]
edg = [BLE, BLE, BLE, ORE, BLE, ORE]
bars = ax.bar(range(6), vals, 0.62, color=cols, edgecolor=edg, linewidth=0.4)
for r, v in zip(bars, vals):
    ax.text(r.get_x() + r.get_width() / 2, v + 0.12, f"{v:.1f} s", ha="center",
            va="bottom", fontsize=4.2, fontweight="bold", color="#111111")
ax.set_xticks(range(6))
ax.set_xticklabels(modes, fontsize=4.2)
style(ax, "Median latency (s)", 7.0, [0, 2, 4, 6])
ax.set_title("(a)  Median response latency by task mode", fontsize=4.8,
             fontweight="bold", pad=2.5)

# ---- (b) VRAM ------------------------------------------------------------
ax = fig.add_subplot(gs[1, 0])
b = ax.bar([0, 1], [5.0, 0.0], 0.55, color=[BL, OR], edgecolor=[BLE, ORE],
           linewidth=0.4)
ax.axhline(8.0, color="#777777", linewidth=0.5, linestyle=(0, (3, 2)))
ax.text(1.42, 8.0, "8 GB budget", ha="right", va="bottom", fontsize=3.6,
        color="#666666")
for x, v in zip([0, 1], [5.0, 0.0]):
    ax.text(x, v + 0.25, f"{v:.1f}", ha="center", va="bottom", fontsize=4.2,
            fontweight="bold")
ax.set_xticks([0, 1]); ax.set_xticklabels(["ARIA\n(local)", "Mark\n(cloud)"], fontsize=4.2)
style(ax, "Peak GPU VRAM (GB)", 10.0, [0, 2, 4, 6, 8])
ax.set_title("(b)  GPU VRAM", fontsize=4.8, fontweight="bold", pad=2.5)

# ---- (c) RAM -------------------------------------------------------------
ax = fig.add_subplot(gs[1, 1])
ax.bar([0, 1], [3.1, 0.7], 0.55, color=[BL, OR], edgecolor=[BLE, ORE],
       linewidth=0.4)
for x, v in zip([0, 1], [3.1, 0.7]):
    ax.text(x, v + 0.1, f"{v:.1f}", ha="center", va="bottom", fontsize=4.2,
            fontweight="bold")
ax.set_xticks([0, 1]); ax.set_xticklabels(["ARIA\n(local)", "Mark\n(cloud)"], fontsize=4.2)
style(ax, "Peak system RAM (GB)", 4.0, [0, 1, 2, 3, 4])
ax.set_title("(c)  System RAM", fontsize=4.8, fontweight="bold", pad=2.5)

# ---- (d) network ---------------------------------------------------------
ax = fig.add_subplot(gs[1, 2])
ax.bar([0, 1], [0.0, 38.0], 0.55, color=[BL, OR], edgecolor=[BLE, ORE],
       linewidth=0.4)
ax.text(0, 1.5, "0", ha="center", va="bottom", fontsize=4.2, fontweight="bold")
ax.text(1, 39.5, "~38", ha="center", va="bottom", fontsize=4.2, fontweight="bold")
ax.set_xticks([0, 1]); ax.set_xticklabels(["ARIA\n(local)", "Mark\n(cloud)"], fontsize=4.2)
style(ax, "Payload (KB / request)", 52.0, [0, 20, 40])
ax.set_title("(d)  Network", fontsize=4.8, fontweight="bold", pad=2.5)

fig.savefig("fig3_latency_hw.pdf", format="pdf")
print("ok")
