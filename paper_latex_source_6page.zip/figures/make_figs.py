import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrow
import matplotlib.font_manager as fm

plt.rcParams.update({
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "font.family": "DejaVu Sans",
    "axes.linewidth": 0.6,
})

BLUE_E, BLUE_F = "#1f5c8b", "#dce9f5"
ORNG_E, ORNG_F = "#c1541c", "#fbe3d2"
TXT = "#111111"

# ----------------------------------------------------------------- Figure 1
aria = [
    ("User Input", "Text / Microphone via Google Speech API"),
    ("Command Parser", "prompt template → Ollama HTTP API"),
    ("Local LLM Inference", "llama3 (8B, Q4) via Ollama — 100% on-device"),
    ("JSON Action Plan", "{action, args}"),
    ("Execution Router (engine.py)", "dispatches to one of 14 tool functions"),
    ("Tool Layer (tools.py)", "File ops · App launch · Search · Browser · Sys. info"),
    ("In-Memory Session Log", "Python dict, cleared on exit"),
]
mark = [
    ("User Input", "Text / Real-Time Voice Stream"),
    ("Planner Module", "structured prompt → Gemini API"),
    ("Cloud LLM Inference", "Gemini 2.5 Flash / Flash-Lite — network required"),
    ("Multi-Step Plan", "up to 5 ordered tool calls"),
    ("Executor + Error Handler (agent/)", "automatic replanning on tool failure"),
    ("Tool Layer (actions/, 17 modules)", "File · Browser · Dev agent · Screen · Games · Comms"),
    ("Persistent JSON Memory", "long_term.json, capped at 2200 chars"),
]

fig = plt.figure(figsize=(3.45, 1.92), dpi=600)
ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, 100); ax.set_ylim(0, 100); ax.axis("off")

ax.text(50, 97.5, "Local LLM Pipeline (ARIA) vs. Cloud API Pipeline (Mark-XXXIX)",
        ha="center", va="top", fontsize=5.6, fontweight="bold", color=TXT)

cols = [(1.0, 47.5, aria, BLUE_E, BLUE_F, "ARIA — Local Inference"),
        (52.5, 99.0, mark, ORNG_E, ORNG_F, "Mark-XXXIX — Cloud API")]

top, bot = 87.0, 8.0
n = 7
slot = (top - bot) / n
bh = slot * 0.74

for x0, x1, items, ec, fc, head in cols:
    cx = (x0 + x1) / 2
    ax.text(cx, 91.5, head, ha="center", va="center", fontsize=5.3,
            fontweight="bold", color=ec)
    for i, (t1, t2) in enumerate(items):
        ytop = top - i * slot
        y0 = ytop - bh
        ax.add_patch(FancyBboxPatch((x0, y0), x1 - x0, bh,
                     boxstyle="round,pad=0,rounding_size=0.8",
                     linewidth=0.55, edgecolor=ec, facecolor=fc))
        ax.text(cx, y0 + bh * 0.66, t1, ha="center", va="center",
                fontsize=4.35, fontweight="bold", color=TXT)
        ax.text(cx, y0 + bh * 0.24, t2, ha="center", va="center",
                fontsize=3.85, color="#333333")
        if i < n - 1:
            ax.annotate("", xy=(cx, ytop - slot), xytext=(cx, y0),
                        arrowprops=dict(arrowstyle="-|>", color="#444444",
                                        linewidth=0.55, mutation_scale=4))

ax.text((1.0 + 47.5) / 2, 4.0,
        "Reasoning network dependency: none\nGUI: CustomTkinter · Windows-tested",
        ha="center", va="center", fontsize=3.7, style="italic", color="#444444")
ax.text((52.5 + 99.0) / 2, 4.0,
        "Reasoning network dependency: required\nGUI: PyQt6 · Windows / macOS / Linux",
        ha="center", va="center", fontsize=3.7, style="italic", color="#444444")

fig.savefig("fig1_architecture.pdf", format="pdf")
plt.close(fig)

# ----------------------------------------------------------------- Figure 2
cats = ["File\nOperations", "File\nSearch", "App Launch\n& Control",
        "Multi-Step\nComposite", "GUI\nAutomation", "Web / Info.\nRetrieval"]
a = [94.6, 79.4, 90.9, 78.8, 84.2, 71.4]
m = [88.1, 91.7, 95.5, 86.5, 80.3, 95.2]

fig, ax = plt.subplots(figsize=(3.45, 1.68), dpi=600)
xs = range(len(cats))
w = 0.38
b1 = ax.bar([x - w / 2 for x in xs], a, w, label="ARIA (local llama3)",
            color="#1f5c8b", edgecolor="#123c5c", linewidth=0.4)
b2 = ax.bar([x + w / 2 for x in xs], m, w, label="Mark-XXXIX (Gemini API)",
            color="#d2691e", edgecolor="#96491a", linewidth=0.4)

for bars, vals in ((b1, a), (b2, m)):
    for r, v in zip(bars, vals):
        ax.text(r.get_x() + r.get_width() / 2, v + 1.2, f"{v:.1f}",
                ha="center", va="bottom", fontsize=4.3, fontweight="bold",
                color="#111111")

ax.set_ylabel("Task success rate (%)", fontsize=5.6)
ax.set_ylim(0, 108)
ax.set_yticks([0, 20, 40, 60, 80, 100])
ax.set_xticks(list(xs))
ax.set_xticklabels(cats, fontsize=4.8)
ax.tick_params(axis="y", labelsize=5.0, length=2, width=0.5, pad=1.5)
ax.tick_params(axis="x", length=0, pad=1.5)
ax.grid(axis="y", color="#cccccc", linewidth=0.4, alpha=0.8)
ax.set_axisbelow(True)
for sp in ("top", "right"):
    ax.spines[sp].set_visible(False)
for sp in ("left", "bottom"):
    ax.spines[sp].set_linewidth(0.5)
ax.legend(fontsize=4.9, ncol=2, loc="upper center", bbox_to_anchor=(0.5, 1.13),
          frameon=False, handlelength=1.2, handleheight=0.8, columnspacing=1.4,
          handletextpad=0.5)
fig.tight_layout(pad=0.25)
fig.savefig("fig8_successrate.pdf", format="pdf")
plt.close(fig)
print("ok")
